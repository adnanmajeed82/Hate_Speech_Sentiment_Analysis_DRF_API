from django.apps import AppConfig


class SentimentAnalysisAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sentiment_analysis_app'
